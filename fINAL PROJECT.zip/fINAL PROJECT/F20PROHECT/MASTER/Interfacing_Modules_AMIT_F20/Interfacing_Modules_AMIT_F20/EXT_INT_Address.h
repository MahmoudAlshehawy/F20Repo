/*
 * EXT_INT_Address.h
 *
 * Created: 8/20/2021 1:41:52 PM
 *  Author: karim
 */ 


#ifndef EXT_INT_ADDRESS_H_
#define EXT_INT_ADDRESS_H_


/************************************** INTERRUPT-Registers *******************************************/
/*
#define SREG    (*(volatile Uint8t*) (0x5F))
#define GICR    (*(volatile Uint8t*) (0x5B))
#define GIFR    (*(volatile Uint8t*) (0x5A))
#define MCUCR   (*(volatile Uint8t*) (0x55))
#define MCUCSR  (*(volatile Uint8t*) (0x54))
*/


#endif /* EXT_INT_ADDRESS_H_ */