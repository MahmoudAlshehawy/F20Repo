/*
 * Interfacing_Modules_Amit_F20.c
 *
 * Created: 9/15/2021 4:46:24 PM
 * Author : Mahmoud
 */ 
 #include "OUTPUT_Module.h"
 #include "EXT_INT.h"
 #include "UART.h"
 #include "SPI.h"

int main(void)
{
	uint8_t Data_recieved;
	LED0_Initialize();
	 LED0_Initialize();
	 LED1_Initialize();
	 LED2_Initialize();

	SPI_Init();
   
   
	/* Replace with your application code*/
    while (1) 
    {
		Data_recieved=SPI_Receive();
	   //TO MAKE SURE SPI IS OK(SLAVE)
	    switch(Data_recieved){
		    case '7':
		    LED0_ON();
		    break;
		    case '8':
		    LED1_ON();
		    break;
		    case '9':
		    LED2_ON();
		    break;
		    case 'A':
		    LED0_OFF();
		    break;
		    case 'B':
		    LED1_OFF();
		    break;
		    case'C':
          	LED2_OFF();
		  	break;
		  	}
	
	
	
	


	
		
    }
}


