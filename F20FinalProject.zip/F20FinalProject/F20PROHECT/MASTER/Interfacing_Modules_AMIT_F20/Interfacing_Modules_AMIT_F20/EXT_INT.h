/*
 * EXT_INT.h
 *
 * Created: 1/23/2021 8:41:01 PM
 *  Author: karim
 */ 


#ifndef EXT_INT_H_
#define EXT_INT_H_

#include "EXT_INT_CONFIG.h"

void GLOBAL_INTERRUPT_Init(void);

void EXT_INTERRUPT0_Init(void);

void EXT_INTERRUPT1_Init(void);

void EXT_INTERRUPT2_Init(void);


#endif /* EXT_INT_H_ */