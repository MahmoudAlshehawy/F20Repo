/*
 * ADRESS_SPL.h
 *
 * Created: 11/22/2021 1:23:38 PM
 *  Author: Mahmoud
 */ 
#ifndef ADRESS_SPL_H_
#define ADRESS_SPL_H_
/*
#define SPCR (*(volatile Uint8t*)(0x2D))
#define SPSR (*(volatile Uint8t*)(0x2E))
#define SPDR (*(volatile Uint8t*)(0x2F))
*/
#endif /* ADRESS_SPL_H_ */